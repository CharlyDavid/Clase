iPod 20

Default skin width: 188
Default skin height: 300

To use this skin, upload the skin_name.xml 
file to your wimpy folder on your web site. 
Then use the Customizer Tool at wimpyplayer.com 
to generate the proper HTML code for the skin.

For more information visit:
http://www.wimpyplayer.com/skins/


